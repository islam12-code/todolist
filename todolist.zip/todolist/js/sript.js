const todoInput = document.getElementById('todoInput');
const abbTodoBtn = document.getElementById('abbToboBtn');
const todolist = document.getElementById('todolist')

function addTodo(){
    let todoInputItem = todoInput.value;
    let todoItem = document.createElement('li')
    if (todoInput.value !== ''){
         todoItem.innerText = todoInputItem;

        const deleteBtn = document.createElement('button')
        deleteBtn.innerText =  ' Удалть';
        deleteBtn.classList.add('deleteBtn')

        deleteBtn.addEventListener('click', () =>{
             todolist.removeChild(todoItem);
        })

        todoItem.appendChild(deleteBtn);


         todolist.appendChild(todoItem);
         todoInput.value = '';


    }else{
        alert('Тапшырма жазыныс')

}
    }

